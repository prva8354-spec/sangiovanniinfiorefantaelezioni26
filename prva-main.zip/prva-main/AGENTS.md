# AGENTS.md — FantaElezioni SGF 2026

## Project overview

Fantasy election game for the San Giovanni in Fiore 2026 municipal elections. Users register, create a team (1 mayor + 5-10 councillors + percentage predictions), and earn points based on real results.

## Key directories

```
src/
  data/candidates.ts    — All candidates: mayors[], lists[], allCouncilors[], helpers
  routes/               — TanStack Start file-based routing
    index.tsx           — Home page
    login.tsx           — Login/signup (Netlify Identity)
    squadra.tsx         — Team creation/view (requires auth)
    classifica.tsx      — Public leaderboard with live score calculation
    live.tsx            — Real-time election results (polls /api/results every 30s)
    regolamento.tsx     — Game rules page
    admin.tsx           — Admin panel (password: Fanta26.invenzione, NOT Identity)
    api/
      teams.ts          — GET/POST user team (requires Identity JWT)
      results.ts        — GET election results + live data (public)
      admin.ts          — Admin CRUD (password via x-admin-password header)
      classifica-data.ts — Public team list for leaderboard
  lib/
    auth.ts             — getServerUser() server function
    identity-context.tsx — React context for client-side auth state
  middleware/
    identity.ts         — TanStack Start middleware for auth
  components/
    NavBar.tsx          — Sticky nav with auth state
    CallbackHandler.tsx — Handles Identity OAuth/confirmation URL hashes
db/
  schema.ts             — Drizzle schema (teams, election_results, live_updates)
  index.ts              — Drizzle client (netlify-db adapter)
netlify/
  database/migrations/  — Auto-generated SQL migrations (via drizzle-kit generate)
```

## Scoring logic

Score calculation lives in two places (keep in sync):
- `src/routes/classifica.tsx` — client-side leaderboard
- `src/routes/admin.tsx` — admin overview

Rules: mayor elected 1st round +75, ballot +35, 2nd place +25, <10% -10; councillor elected +30, list above threshold +10; percentage bonus max +25 minus 1 per % point diff, min 0.

## Candidate data

All candidates are in `src/data/candidates.ts`. IDs are short slugs (e.g. `ambrogio`, `as-fragale-f`). The `lists` array groups councillors by list, each list has a `mayorId` linking it to a mayoral candidate.

## Admin authentication

The admin panel uses a simple password (`Fanta26.invenzione`) sent as `x-admin-password` HTTP header — it does NOT use Netlify Identity. This is intentional to keep admin access independent of the Identity system.

## Conventions

- All API routes are under `src/routes/api/` using TanStack Start's `server.handlers`
- DB imports use `.js` extensions for ESM compatibility
- Tailwind classes use `slate-*` for backgrounds, `amber-*` for accents
- Identity only works on deployed Netlify — not localhost

## Project Overview

An interactive resume/portfolio application with an AI-powered assistant. Built with TanStack Start and deployed on Netlify.

### Tech Stack

| Layer | Technology |
|-------|------------|
| Framework | TanStack Start |
| Frontend | React 19, TanStack Router v1 |
| Build | Vite 7 |
| Styling | Tailwind CSS 4 |
| UI Components | Radix UI + custom components |
| Content | Content Collections (type-safe markdown) |
| AI | TanStack AI with multi-provider support |
| Language | TypeScript 5.7 (strict mode) |
| Deployment | Netlify |

## Directory Structure

```
├── public
│   ├── favicon.ico
│   ├── logo.png
│   ├── tanstack-circle-logo.png
│   └── tanstack-word-logo-white.svg  # TanStack wordmark logo (white) used in header/nav.
├── src
│   ├── components
│   │   ├── Header.tsx  # Header.
│   │   ├── HeaderNav.tsx  # Navigation sidebar template: mobile menu, Home link, add-on routes; EJS-driven for dynamic route generation.
│   │   ├── ProductAIAssistant.tsx  # AI marketing assistant.
│   │   └── ProductRecommendation.tsx  # Product recommendation card.
│   ├── data
│   │   └── products.ts  # Product catalog data template.
│   ├── lib
│   │   ├── product-ai-hook.ts  # useProductChat hook.
│   │   └── product-tools.ts  # AI tools: getProducts, recommendProduct.
│   ├── routes
│   │   ├── products
│   │   │   └── $productId.tsx  # Product detail page with recommendation.
│   │   ├── __root.tsx  # Root layout: Header, styles.
│   │   ├── api.product-chat.ts  # POST handler for product AI chat.
│   │   └── index.tsx  # Marketing home with ProductAIAssistant.
│   ├── store
│   │   └── product-assistant.ts  # Zustand store for assistant state.
│   ├── router.tsx  # TanStack Router setup: creates router from generated routeTree with scroll restoration.
│   └── styles.css  # Global styles.
├── .gitignore  # Template for .gitignore: node_modules, dist, .env, .netlify, .tanstack, etc.
├── AGENTS.md  # This document provides an overview of the project structure for developers and AI agents working on this codebase.
├── netlify.toml  # Netlify deployment config: build command (vite build), publish directory (dist/client), and dev server settings (port 8888, target 3000).
├── package.json  # Project manifest with TanStack Start, React 19, Vite 7, Tailwind CSS 4, and Netlify plugin dependencies; defines dev and build scripts.
├── pnpm-lock.yaml
├── tsconfig.json  # TypeScript config: ES2022 target, strict mode, @/* path alias for src/*, bundler module resolution.
└── vite.config.ts  # Vite config template: TanStack Start, React, Tailwind, Netlify plugin, and optional add-on integrations; processed by EJS.
```

## Key Concepts

### File-Based Routing (TanStack Router)

Routes are defined by files in `src/routes/`:

- `__root.tsx` - Root layout wrapping all pages
- `index.tsx` - Route for `/`
- `api.*.ts` - Server API endpoints (e.g., `api.resume-chat.ts` → `/api/resume-chat`)

### Component Architecture

**UI Primitives** (`src/components/ui/`):
- Radix UI-based, Tailwind-styled
- Card, Badge, Checkbox, Separator, HoverCard

**Feature Components** (`src/components/`):
- Header, HeaderNav, ResumeAssistant

## Configuration Files

| File | Purpose |
|------|---------|
| `vite.config.ts` | Vite plugins: TanStack Start, Netlify, Tailwind, Content Collections |
| `tsconfig.json` | TypeScript config with `@/*` path alias for `src/*` |
| `netlify.toml` | Build command, output directory, dev server settings |
| `content-collections.ts` | Zod schemas for jobs and education frontmatter |
| `styles.css` | Tailwind imports + CSS custom properties (oklch colors) |

## Development Commands

```bash
npm run dev      # Start dev server
npm run build    # Production build
npm run preview  # Preview production build
```

## Conventions

### Naming
- Components: PascalCase
- Utilities/hooks: camelCase
- Routes: kebab-case files

### Styling
- Tailwind CSS utility classes
- `cn()` helper for conditional class merging
- CSS variables for theme tokens in `styles.css`

### TypeScript
- Strict mode enabled
- Import paths use `@/` alias
- Zod for runtime validation
- Type-only imports with `type` keyword

### State Management
- React hooks for local state
- Zustand if you need it for global state
### Marketing Site with AI Assistant

Marketing site with TanStack AI chat assistant. No Stripe checkout.

**AI tools available:**
- `getProducts` - Get all products from catalog
- `recommendProduct` - Display product recommendation card (MUST use for recommendations)

**Components:** ProductAIAssistant, ProductRecommendation

**Dependencies:** @tanstack/ai, streamdown

## Environment Variables

For AI: ANTHROPIC_API_KEY, OPENAI_API_KEY, GEMINI_API_KEY, or OLLAMA_BASE_URL (same as ai add-on).

## Application Name

This starter uses "Application Name" as a placeholder throughout the UI and metadata. Replace it with the user's desired application name in the following locations:

### UI Components
- `src/components/Header.tsx` — app name displayed in the header
- `src/components/HeaderNav.tsx` — app name in the mobile navigation header

### SEO Metadata
- `src/routes/__root.tsx` — the `title` field in the `head()` configuration

Search for all occurrences of "Application Name" in the `src/` directory and replace with the user's application name.
